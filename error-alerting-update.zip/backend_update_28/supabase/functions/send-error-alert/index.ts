import { sendEmail, emailShell } from "../_shared/email.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface AlertRequest {
  alertEmail: string;
  source: string;
  errorMessage: string;
  severity: string;
  createdAt: string;
}

/**
 * Called only by the database trigger on app_error_log
 * (trg_error_alert, migration 20260806080000) via pg_net — not intended
 * to be called directly by the frontend or an admin action, which is
 * why this doesn't check for a pupil/admin session the way most
 * functions in this project do. The throttling (at most one email per
 * error source per 15 minutes) already happened in the trigger before
 * this function was ever invoked; this function's only job is sending
 * the one email it's asked to send.
 *
 * Reuses the exact same Resend integration as send-welcome-email and
 * send-weekly-digest — no new email provider, no new secret beyond what
 * those two functions already require.
 */
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { alertEmail, source, errorMessage, severity, createdAt }: AlertRequest = await req.json();
    if (!alertEmail || !source) {
      return new Response(JSON.stringify({ error: "alertEmail and source are required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const html = emailShell(
      "New error logged",
      `
      <p style="margin:0 0 12px;">A ${severity || "error"} was just logged on SmartClass Zambia:</p>
      <table width="100%" cellpadding="6" style="background-color:#F6F3EA;border-radius:8px;font-size:14px;">
        <tr><td style="color:#666;width:100px;">Source</td><td style="font-family:monospace;">${source}</td></tr>
        <tr><td style="color:#666;">Message</td><td>${errorMessage}</td></tr>
        <tr><td style="color:#666;">When</td><td>${createdAt}</td></tr>
      </table>
      <p style="margin:16px 0 0;font-size:13px;color:#666;">
        Further errors from this same source in the next 15 minutes won't trigger another email — check the
        System Health tab in the admin panel for the full picture.
      </p>
      `
    );

    const sent = await sendEmail(alertEmail, `SmartClass Zambia: ${severity || "error"} in ${source}`, html);

    return new Response(JSON.stringify({ sent }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("send-error-alert error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
