"use client";

import { useEffect, useState } from "react";
import RequireAuth from "@/components/RequireAuth";
import { api } from "@/lib/api";

type Progress = {
  subject_id: number;
  topic_id: number;
  topic_title: string;
  mastery_score: number;
  lessons_completed: number;
  questions_attempted: number;
  questions_correct: number;
};

function ProgressInner() {
  const [rows, setRows] = useState<Progress[]>([]);

  useEffect(() => {
    api.get("/api/progress").then(setRows);
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold text-brand-900 mb-6">Your progress</h1>
      {rows.length === 0 ? (
        <p className="text-brand-700">No lessons completed yet -- head to your dashboard to start one.</p>
      ) : (
        <div className="space-y-4">
          {rows.map((r) => (
            <div key={r.topic_id} className="card">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-bold text-brand-900">{r.topic_title}</h4>
                <span className="text-brand-700 font-semibold">{r.mastery_score}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-brand-100 overflow-hidden">
                <div className="h-2 bg-brand-600" style={{ width: `${Math.min(100, r.mastery_score)}%` }} />
              </div>
              <p className="text-sm text-brand-700 mt-2">
                {r.lessons_completed} lesson(s) completed &middot; {r.questions_correct}/{r.questions_attempted} comprehension
                checks correct
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function ProgressPage() {
  return (
    <RequireAuth>
      <ProgressInner />
    </RequireAuth>
  );
}
