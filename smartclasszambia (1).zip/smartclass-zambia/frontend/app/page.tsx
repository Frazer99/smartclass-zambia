import Link from "next/link";

export default function Home() {
  return (
    <div>
      <section className="max-w-6xl mx-auto px-4 py-16 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <p className="text-accent-600 font-semibold mb-2">Powered by ZedCode Technologies</p>
          <h1 className="text-4xl md:text-5xl font-extrabold text-brand-900 leading-tight">
            Your AI Teacher, <span className="text-brand-600">Anytime, Anywhere.</span>
          </h1>
          <p className="mt-4 text-lg text-brand-800/80">
            SmartClass Zambia is a voice- and video-interactive AI tutor aligned to the ECZ curriculum for
            Forms 2 to 6. Learn Mathematics, Physics, Chemistry and Science with a teacher that explains, checks
            your understanding, and adapts -- on a smart whiteboard, at your own pace.
          </p>
          <div className="mt-8 flex gap-4">
            <Link href="/register" className="btn-primary">
              Start learning free
            </Link>
            <Link href="/login" className="btn-secondary">
              I already have an account
            </Link>
          </div>
          <p className="mt-4 text-sm text-brand-700/70">
            10 minutes free per subject, no card required. Then subscribe for just K50/subject/month.
          </p>
        </div>
        <div className="card">
          <h3 className="font-bold text-brand-900 mb-3">What you get</h3>
          <ul className="space-y-2 text-brand-800">
            <li>&#8226; An AI teacher that speaks, listens and writes on a smart board</li>
            <li>&#8226; Lessons built from your school's approved syllabus, books and pamphlets</li>
            <li>&#8226; A dedicated Past Paper section -- pick a paper, or a single question, and get walked through it</li>
            <li>&#8226; Instant marking and a progress tracker per topic</li>
            <li>&#8226; Zambian-context examples, ECZ exam-style practice</li>
          </ul>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 pb-16 grid md:grid-cols-3 gap-6">
        <div className="card">
          <h4 className="font-bold text-brand-900 mb-1">Form 2 &amp; 3</h4>
          <p className="text-brand-700">Mathematics, Science</p>
        </div>
        <div className="card">
          <h4 className="font-bold text-brand-900 mb-1">Form 4, 5 &amp; 6</h4>
          <p className="text-brand-700">Mathematics, Physics, Chemistry</p>
        </div>
        <div className="card">
          <h4 className="font-bold text-brand-900 mb-1">Simple pricing</h4>
          <p className="text-brand-700">K50/subject/month &middot; MTN Money, Airtel Money &amp; Visa</p>
        </div>
      </section>
    </div>
  );
}
