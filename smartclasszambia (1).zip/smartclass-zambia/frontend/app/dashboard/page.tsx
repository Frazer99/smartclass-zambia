"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import RequireAuth from "@/components/RequireAuth";
import { useAuth } from "@/lib/auth";
import { api } from "@/lib/api";

type Subject = { id: number; name: string; description?: string };
type Trial = { subject_id: number; seconds_used: number; seconds_allowed: number; seconds_remaining: number; has_active_subscription: boolean };

function DashboardInner() {
  const { user } = useAuth();
  const [formLevel, setFormLevel] = useState(user?.form_level || 4);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [trials, setTrials] = useState<Record<number, Trial>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api
      .get(`/api/catalog/subjects?form_level=${formLevel}`)
      .then(async (subs: Subject[]) => {
        setSubjects(subs);
        const entries = await Promise.all(
          subs.map(async (s) => {
            const t = await api.get(`/api/lessons/trial-status/${s.id}`);
            return [s.id, t] as const;
          })
        );
        setTrials(Object.fromEntries(entries));
      })
      .finally(() => setLoading(false));
  }, [formLevel]);

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between flex-wrap gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-brand-900">Welcome, {user?.full_name?.split(" ")[0]}</h1>
          <p className="text-brand-700">Pick a subject to jump into a lesson or a past paper.</p>
        </div>
        <div>
          <label className="text-sm font-medium text-brand-800 mr-2">Form</label>
          <select className="input w-auto" value={formLevel} onChange={(e) => setFormLevel(Number(e.target.value))}>
            {[2, 3, 4, 5, 6].map((f) => (
              <option key={f} value={f}>
                Form {f}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <p className="text-brand-700">Loading subjects...</p>
      ) : subjects.length === 0 ? (
        <p className="text-brand-700">No subjects have been configured for this Form yet. Check back soon.</p>
      ) : (
        <div className="grid md:grid-cols-3 gap-6">
          {subjects.map((s) => {
            const t = trials[s.id];
            return (
              <div key={s.id} className="card flex flex-col">
                <h3 className="text-lg font-bold text-brand-900">{s.name}</h3>
                <p className="text-brand-700 text-sm flex-1 mt-1">{s.description}</p>
                <div className="mt-4 text-sm">
                  {t?.has_active_subscription ? (
                    <span className="inline-block px-2 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold">
                      Subscribed
                    </span>
                  ) : (
                    <span className="inline-block px-2 py-1 rounded-full bg-accent-500/10 text-accent-600 font-semibold">
                      {Math.max(0, Math.round((t?.seconds_remaining ?? 600) / 60))} free min left
                    </span>
                  )}
                </div>
                <div className="mt-4 flex gap-2">
                  <Link href={`/subjects?subjectId=${s.id}&formLevel=${formLevel}&tab=lesson`} className="btn-primary flex-1 text-sm py-2">
                    Lesson
                  </Link>
                  <Link
                    href={`/subjects?subjectId=${s.id}&formLevel=${formLevel}&tab=pastpaper`}
                    className="btn-secondary flex-1 text-sm py-2"
                  >
                    Past Papers
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function DashboardPage() {
  return (
    <RequireAuth>
      <DashboardInner />
    </RequireAuth>
  );
}
