'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Brain, Sparkles, Loader as Loader2 } from 'lucide-react';

interface EscalatedTopic {
  topic_id: string;
  name: string;
  attempt_count: number;
}

// Pupil-friendly labels for the same strategy keys ai-teacher-chat uses
// internally (STRATEGY_DESCRIPTIONS there is phrased as an instruction
// TO the AI — "a direct, step-by-step mathematical explanation" — not
// something a pupil should read verbatim; these say the same thing in
// a way meant for the pupil themselves).
const STRATEGY_LABELS: Record<string, string> = {
  direct: 'clear, step-by-step explanations',
  visual: 'diagrams and visual explanations',
  local_example: 'real-world, everyday examples',
  step_by_step: 'breaking things into very small steps',
};

/**
 * All the adaptive learning intelligence built into this platform —
 * which explanation style tends to work for this specific pupil, which
 * topics the AI is currently adapting its approach for — was previously
 * invisible to the pupil it's actually about. This surfaces it directly,
 * reading get_preferred_learning_style() and topic_explanation_attempts,
 * both already populated by ai-teacher-chat during ordinary lesson
 * conversations — no new tracking, just showing what was already there.
 */
export function LearningProfile() {
  const [preferredStyle, setPreferredStyle] = useState<string | null>(null);
  const [escalatedTopics, setEscalatedTopics] = useState<EscalatedTopic[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { setLoading(false); return; }
      const [styleRes, escalatedRes] = await Promise.all([
        supabase.rpc('get_preferred_learning_style', { p_student_id: session.user.id }),
        supabase.from('topic_explanation_attempts')
          .select('topic_id, attempt_count, topic:topics(name)')
          .eq('student_id', session.user.id).gt('attempt_count', 0)
          .order('attempt_count', { ascending: false }),
      ]);
      setPreferredStyle(styleRes.data?.[0]?.strategy || null);
      setEscalatedTopics(
        (escalatedRes.data || []).map((row: any) => ({
          topic_id: row.topic_id, name: row.topic?.name || 'Topic', attempt_count: row.attempt_count,
        }))
      );
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return <div className="flex h-24 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>;
  }

  if (!preferredStyle && escalatedTopics.length === 0) {
    return null;
  }

  return (
    <div className="card-board p-5">
      <div className="flex items-center gap-2 mb-3">
        <Brain className="h-5 w-5 text-gold" />
        <h2 className="font-display text-lg font-semibold text-chalk">How You Learn Best</h2>
      </div>

      {preferredStyle && STRATEGY_LABELS[preferredStyle] && (
        <p className="text-sm text-chalk mb-3">
          Over time, you&apos;ve tended to understand things best with{' '}
          <span className="text-gold font-semibold">{STRATEGY_LABELS[preferredStyle]}</span> — your teachers now
          lean toward this style from the start of an explanation, not just when you&apos;re stuck.
        </p>
      )}

      {escalatedTopics.length > 0 && (
        <div className={preferredStyle ? 'mt-3 pt-3 border-t border-white/10' : ''}>
          <div className="flex items-center gap-1.5 mb-2">
            <Sparkles className="h-3.5 w-3.5 text-gold" />
            <p className="text-xs uppercase tracking-widest text-muted-board font-semibold">Getting extra attention right now</p>
          </div>
          <div className="space-y-1">
            {escalatedTopics.map((t) => (
              <p key={t.topic_id} className="text-sm text-muted-board">
                <span className="text-chalk">{t.name}</span> — your teacher is trying a different way to explain this one
              </p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
