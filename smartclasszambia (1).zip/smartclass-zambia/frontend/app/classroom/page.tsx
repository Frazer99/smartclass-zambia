"use client";

import { Suspense, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import RequireAuth from "@/components/RequireAuth";
import PaywallModal from "@/components/PaywallModal";
import Whiteboard from "@/components/Whiteboard";
import { api, ApiError } from "@/lib/api";

type Message = { id: number; role: string; content: string; whiteboard?: { type: string; content: string }[] | null };
type SessionOut = {
  id: number;
  mode: string;
  subject_id: number;
  ended_at?: string | null;
  messages: Message[];
};

function ClassroomInner() {
  const params = useSearchParams();
  const router = useRouter();
  const mode = params.get("mode"); // "lesson" | "pastpaper" | "paywall"
  const sessionId = params.get("sessionId");
  const subjectId = Number(params.get("subjectId"));

  const [session, setSession] = useState<SessionOut | null>(null);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [showPaywall, setShowPaywall] = useState(mode === "paywall");
  const [subjectName, setSubjectName] = useState("this subject");
  const lastMsgTime = useRef<number>(Date.now());
  const bottomRef = useRef<HTMLDivElement>(null);

  const apiBase = mode === "pastpaper" ? "/api/past-papers" : "/api/lessons";

  useEffect(() => {
    api.get("/api/catalog/subjects").then((subs: any[]) => {
      const s = subs.find((s) => s.id === subjectId);
      if (s) setSubjectName(s.name);
    });
  }, [subjectId]);

  useEffect(() => {
    if (!sessionId) return;
    api.get(`${apiBase}/${sessionId}`).then((s) => {
      setSession(s);
      lastMsgTime.current = Date.now();
    });
  }, [sessionId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [session?.messages?.length]);

  async function sendMessage(content: string) {
    if (!sessionId || !content.trim()) return;
    setSending(true);
    const elapsed = Math.min(600, Math.max(3, Math.round((Date.now() - lastMsgTime.current) / 1000)));
    lastMsgTime.current = Date.now();
    try {
      const res = await api.post(`${apiBase}/message`, { session_id: Number(sessionId), content, elapsed_seconds: elapsed });
      setSession(res);
      setInput("");
    } catch (err) {
      if (err instanceof ApiError && err.status === 402) {
        setShowPaywall(true);
      }
    } finally {
      setSending(false);
    }
  }

  const lastTeacherMsg = [...(session?.messages || [])].reverse().find((m) => m.role === "teacher");

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="font-bold text-brand-900">
          {mode === "pastpaper" ? "Past Paper" : "Lesson"} &middot; {subjectName}
        </h1>
        <button className="btn-secondary text-sm py-1.5 px-3" onClick={() => router.push("/dashboard")}>
          Back to dashboard
        </button>
      </div>

      <div className="grid md:grid-cols-2 gap-6" style={{ minHeight: "60vh" }}>
        <div className="card flex flex-col" style={{ height: "65vh" }}>
          <h3 className="font-semibold text-brand-800 mb-2 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-brand-600 text-white text-xs grid place-items-center">AI</span>
            AI Teacher
          </h3>
          <div className="flex-1 overflow-y-auto space-y-3 pr-1">
            {(session?.messages || []).map((m) => (
              <div key={m.id} className={`flex ${m.role === "student" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`rounded-2xl px-4 py-2 max-w-[85%] text-sm whitespace-pre-wrap ${
                    m.role === "student" ? "bg-brand-600 text-white" : "bg-brand-50 text-brand-900"
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}
            <div ref={bottomRef} />
          </div>
          {session?.ended_at ? (
            <p className="text-sm text-brand-600 mt-3 text-center">This session has ended.</p>
          ) : (
            <form
              className="mt-3 flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                sendMessage(input);
              }}
            >
              <input
                className="input flex-1"
                placeholder={mode === "pastpaper" ? "Ask why, or type 'next'..." : "Type your answer..."}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={sending}
              />
              <button className="btn-primary" disabled={sending}>
                Send
              </button>
            </form>
          )}
        </div>

        <div className="card" style={{ height: "65vh" }}>
          <h3 className="font-semibold text-brand-800 mb-2">Smart Board</h3>
          <div style={{ height: "calc(100% - 2rem)" }}>
            <Whiteboard lines={(lastTeacherMsg?.whiteboard as any) || []} />
          </div>
        </div>
      </div>

      {showPaywall && (
        <PaywallModal
          subjectId={subjectId}
          subjectName={subjectName}
          onClose={() => setShowPaywall(false)}
          onSubscribed={() => setShowPaywall(false)}
        />
      )}
    </div>
  );
}

export default function ClassroomPage() {
  return (
    <RequireAuth>
      <Suspense fallback={<div className="max-w-6xl mx-auto px-4 py-16">Loading...</div>}>
        <ClassroomInner />
      </Suspense>
    </RequireAuth>
  );
}
