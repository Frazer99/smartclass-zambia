/*
# SmartClass Zambia — Real Error Alerting

## Purpose
Closes a real gap named directly when asked about production readiness:
app_error_log (migration 20260804080000) genuinely captures failures,
but nothing notifies anyone — an admin has to remember to open the
System Health tab. This adds an actual email alert on new errors, sent
via the same Resend integration already used for welcome emails and the
weekly digest.

## Why throttled, not one email per error
A real outage (say, both AI providers down at once) could generate
dozens of app_error_log rows in minutes. Sending one email per row
would flood the admin's inbox at exactly the moment they most need a
clear signal, not noise — the classic alert-fatigue failure mode. This
sends at most one alert per (source) per 15-minute window: the first
occurrence triggers an email immediately; further occurrences of the
same source within that window are still logged normally, just don't
trigger another email.

## app_error_log.alert_sent
Tracks whether THIS row already triggered an alert — combined with the
15-minute lookback in the trigger function, this is how the throttling
above is actually implemented, not just described.

## platform_settings.alert_email
Reuses the existing key-value settings table (same pattern as
is_platform_free, subscription_price_zmw, primary_ai_provider) rather
than a new single-purpose table. No default value seeded — alerting
stays off until an admin actually sets a real email address; sending to
an empty/placeholder address would be worse than not alerting at all.

## Trigger, not a polling job
AFTER INSERT on app_error_log, calling pg_net (the same async HTTP
mechanism already used for the welcome-email trigger) rather than a
scheduled pg_cron job — an alert about a NEW error should fire close to
when it happened, not wait for the next poll interval.

Idempotent, no destructive operations.
*/

ALTER TABLE app_error_log ADD COLUMN IF NOT EXISTS alert_sent boolean NOT NULL DEFAULT false;

CREATE OR REPLACE FUNCTION trigger_error_alert()
RETURNS TRIGGER AS $$
DECLARE
  base_url text;
  service_key text;
  alert_email text;
  recent_alert_exists boolean;
BEGIN
  BEGIN
    base_url := current_setting('app.settings.supabase_url', true);
    service_key := current_setting('app.settings.supabase_service_role_key', true);
  EXCEPTION WHEN OTHERS THEN
    base_url := NULL;
  END;

  SELECT (value #>> '{}') INTO alert_email FROM platform_settings WHERE key = 'alert_email';

  -- No app.settings configured (same prerequisite as the welcome email
  -- trigger — see migration 20260720080000) or no alert_email set —
  -- skip quietly, exactly like every other optional-integration
  -- fallback in this project.
  IF base_url IS NULL OR base_url = '' OR service_key IS NULL OR service_key = ''
     OR alert_email IS NULL OR alert_email = '' THEN
    RETURN NEW;
  END IF;

  -- Throttle: has this SAME source already sent an alert in the last
  -- 15 minutes? If so, this row is logged normally but doesn't trigger
  -- a second email.
  SELECT EXISTS (
    SELECT 1 FROM app_error_log
    WHERE source = NEW.source AND alert_sent = true
      AND created_at > now() - interval '15 minutes'
      AND id != NEW.id
  ) INTO recent_alert_exists;

  IF recent_alert_exists THEN
    RETURN NEW;
  END IF;

  PERFORM net.http_post(
    url := base_url || '/functions/v1/send-error-alert',
    headers := jsonb_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || service_key),
    body := jsonb_build_object(
      'alertEmail', alert_email,
      'source', NEW.source,
      'errorMessage', NEW.error_message,
      'severity', NEW.severity,
      'createdAt', NEW.created_at
    )
  );

  UPDATE app_error_log SET alert_sent = true WHERE id = NEW.id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_error_alert ON app_error_log;
CREATE TRIGGER trg_error_alert
  AFTER INSERT ON app_error_log
  FOR EACH ROW EXECUTE FUNCTION trigger_error_alert();
