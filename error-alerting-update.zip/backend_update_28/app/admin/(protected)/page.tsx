'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/components/auth-provider';
import { supabase, Subject, Topic, Lesson, LessonContent, ContentMaterial, PracticeQuestion } from '@/lib/supabase-client';
import { Shield, Loader as Loader2 } from 'lucide-react';
import { toast } from 'sonner';

import { OverviewTab } from './tabs/overview-tab';
import { AnalyticsTab } from './tabs/analytics-tab';
import { MaterialsTab } from './tabs/materials-tab';
import { LessonsTab } from './tabs/lessons-tab';
import { QuestionsTab } from './tabs/questions-tab';
import { UsersTab } from './tabs/users-tab';
import { CurriculumTab } from './tabs/curriculum-tab';
import { ModerationTab } from './tabs/moderation-tab';
import { SchoolAnalyticsTab } from './tabs/school-analytics-tab';
import { BillingTab } from './tabs/billing-tab';
import { PersonasTab } from './tabs/personas-tab';
import { SystemHealthTab } from './tabs/system-health-tab';
import { SettingsTab } from './tabs/settings-tab';
import { UserProfile } from './tabs/constants';

type Tab = 'overview' | 'analytics' | 'school-analytics' | 'billing' | 'personas' | 'materials' | 'lessons' | 'questions' | 'users' | 'curriculum' | 'moderation' | 'system-health' | 'settings';

type ActivityItem = {
  id: string;
  type: 'lesson_completed' | 'practice_attempt' | 'user_joined';
  user_name: string;
  detail: string;
  timestamp: string;
};

const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: 'overview', label: 'Overview', icon: <BarChart3 className="h-4 w-4" /> },
  { id: 'analytics', label: 'Analytics', icon: <TrendingUp className="h-4 w-4" /> },
  { id: 'school-analytics', label: 'School Analytics', icon: <School className="h-4 w-4" /> },
  { id: 'billing', label: 'Billing', icon: <Wallet className="h-4 w-4" /> },
  { id: 'personas', label: 'Personas', icon: <Users2 className="h-4 w-4" /> },
  { id: 'materials', label: 'Materials', icon: <FileText className="h-4 w-4" /> },
  { id: 'lessons', label: 'Lessons', icon: <BookOpen className="h-4 w-4" /> },
  { id: 'questions', label: 'Questions', icon: <HelpCircle className="h-4 w-4" /> },
  { id: 'users', label: 'Users', icon: <Users className="h-4 w-4" /> },
  { id: 'curriculum', label: 'Curriculum', icon: <Layers className="h-4 w-4" /> },
  { id: 'moderation', label: 'Moderation', icon: <ShieldAlert className="h-4 w-4" /> },
  { id: 'system-health', label: 'System Health', icon: <Activity className="h-4 w-4" /> },
  { id: 'settings', label: 'Settings', icon: <Settings className="h-4 w-4" /> },
];

// Import icons used in TABS
import { ChartBar as BarChart3, TrendingUp, FileText, BookOpen, CircleHelp as HelpCircle, Users, Layers, Settings, ShieldAlert, School, Wallet, Users2, Activity } from 'lucide-react';

export default function AdminPage() {
  const { profile } = useAuth();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  // Shared data
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [materials, setMaterials] = useState<ContentMaterial[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [questions, setQuestions] = useState<PracticeQuestion[]>([]);

  // Overview
  const [userCount, setUserCount] = useState(0);
  const [topicCount, setTopicCount] = useState(0);
  const [lessonCount, setLessonCount] = useState(0);
  const [questionCount, setQuestionCount] = useState(0);
  const [usersByGrade, setUsersByGrade] = useState<Record<number, number>>({});
  const [topicsBySubject, setTopicsBySubject] = useState<{ subject: string; count: number; color: string }[]>([]);
  const [activityFeed, setActivityFeed] = useState<ActivityItem[]>([]);
  const [recentSignups, setRecentSignups] = useState<UserProfile[]>([]);

  // Analytics
  const [sessionCount, setSessionCount] = useState(0);
  const [completedSessionCount, setCompletedSessionCount] = useState(0);
  const [attemptCount, setAttemptCount] = useState(0);
  const [correctAttemptCount, setCorrectAttemptCount] = useState(0);
  const [avgMastery, setAvgMastery] = useState(0);
  const [masteryDistribution, setMasteryDistribution] = useState<{ range: string; count: number }[]>([]);
  const [questionsBySubject, setQuestionsBySubject] = useState<{ subject: string; count: number; color: string }[]>([]);
  const [aiTotalMessages, setAiTotalMessages] = useState(0);
  const [aiFallbackRate, setAiFallbackRate] = useState(0);
  const [aiConfusionRate, setAiConfusionRate] = useState(0);
  const [aiRateLimitedCount, setAiRateLimitedCount] = useState(0);
  const [aiEvalRuns, setAiEvalRuns] = useState<{ id: string; run_at: string; total_cases: number; passed_cases: number; avg_score: number }[]>([]);
  const [moderationFlags, setModerationFlags] = useState<any[]>([]);
  const [moderationCleanupLog, setModerationCleanupLog] = useState<any[]>([]);
  const [moderationPage, setModerationPage] = useState(0);
  const [moderationReviewedTotalCount, setModerationReviewedTotalCount] = useState(0);
  const [moderationLoading, setModerationLoading] = useState(true);
  const [schoolList, setSchoolList] = useState<{ school: string; pupil_count: number }[]>([]);
  const [schoolTopicAnalytics, setSchoolTopicAnalytics] = useState<any[]>([]);
  const [commonMisconceptions, setCommonMisconceptions] = useState<any[]>([]);
  const [schoolFilter, setSchoolFilter] = useState<string>('');
  const [schoolGradeFilter, setSchoolGradeFilter] = useState<number | null>(null);
  const [schoolAnalyticsLoading, setSchoolAnalyticsLoading] = useState(true);
  const [payments, setPayments] = useState<any[]>([]);
  const [revenueSummary, setRevenueSummary] = useState<any[]>([]);
  const [isPlatformFree, setIsPlatformFree] = useState(false);
  const [primaryAiProvider, setPrimaryAiProviderState] = useState('openai');
  const [personas, setPersonas] = useState<any[]>([]);
  const [personasLoading, setPersonasLoading] = useState(true);
  const [errorLogs, setErrorLogs] = useState<any[]>([]);
  const [alertEmail, setAlertEmail] = useState('');
  const [errorLogsLoading, setErrorLogsLoading] = useState(true);
  const [subscriptionPrice, setSubscriptionPrice] = useState(50);
  const [billingLoading, setBillingLoading] = useState(true);
  const [subscribersBySubject, setSubscribersBySubject] = useState<any[]>([]);
  const [paymentsPage, setPaymentsPage] = useState(0);
  const [paymentsTotalCount, setPaymentsTotalCount] = useState(0);
  const [aiTopTopics, setAiTopTopics] = useState<{ topic: string; count: number; confusionCount: number }[]>([]);

  // Users
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [userGradeFilter, setUserGradeFilter] = useState<number | null>(null);
  const [usersPage, setUsersPage] = useState(0);
  const [usersTotalCount, setUsersTotalCount] = useState(0);
  const [pendingTeachers, setPendingTeachers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [userProgress, setUserProgress] = useState<any[]>([]);
  const [userSessions, setUserSessions] = useState<any[]>([]);

  // Lessons
  const [lessonSearch, setLessonSearch] = useState('');
  const [lessonTopicFilter, setLessonTopicFilter] = useState<string>('');
  const [showLessonForm, setShowLessonForm] = useState(false);
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null);
  const [lessonForm, setLessonForm] = useState({
    topic_id: '', title: '', difficulty: 'standard', display_order: 0,
    intro: '', summary: '',
  });

  // Questions
  const [questionSearch, setQuestionSearch] = useState('');
  const [questionTopicFilter, setQuestionTopicFilter] = useState<string>('');
  const [showQuestionForm, setShowQuestionForm] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<PracticeQuestion | null>(null);
  const [questionForm, setQuestionForm] = useState({
    topic_id: '', question_text: '', question_type: 'multiple_choice',
    options: ['', '', '', ''], answer_key: '', explanation: '', difficulty: 'standard',
  });

  // Materials
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [syncing, setSyncing] = useState<string | null>(null);
  const [syncResult, setSyncResult] = useState<{ source: string; message: string } | null>(null);
  const [embedding, setEmbedding] = useState(false);
  const [embeddingResult, setEmbeddingResult] = useState<{ embedded: number; failed: number; remaining: number } | null>(null);
  const [form, setForm] = useState({
    title: '', source: '', material_type: 'supplementary', subject_id: '',
    grade: '', source_reference: '', content_summary: '', status: 'pending',
  });

  // Curriculum
  const [curriculumSubjectFilter, setCurriculumSubjectFilter] = useState<string>('');

  useEffect(() => {
    if (!profile) return;
    checkAdmin();
  }, [profile]);

  // Re-run the school-analytics RPCs whenever the filter changes, but not
  // on first mount (isAdmin guards against firing before fetchAll's own
  // initial call, avoiding two overlapping requests for the same data).
  useEffect(() => {
    if (!isAdmin) return;
    fetchSchoolAnalytics();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [schoolFilter, schoolGradeFilter]);

  // A new search or Form filter should always start from page 1 — not
  // wherever the admin happened to be paging through before typing.
  useEffect(() => {
    if (!isAdmin) return;
    setUsersPage(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userSearch, userGradeFilter]);

  useEffect(() => {
    if (!isAdmin) return;
    fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [usersPage, userSearch, userGradeFilter]);

  useEffect(() => {
    if (!isAdmin) return;
    fetchModeration();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [moderationPage]);

  useEffect(() => {
    if (!isAdmin) return;
    fetchBilling();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paymentsPage]);

  const checkAdmin = async () => {
    if (!profile) return;
    const { data } = await supabase.from('profiles').select('role').eq('id', profile.id).maybeSingle();
    if (data?.role !== 'admin') {
      toast.error('Admin access required.');
      router.push('/dashboard');
      return;
    }
    setIsAdmin(true);
    fetchAll();
  };

  const fetchAll = async () => {
    await Promise.all([
      fetchSubjects(), fetchMaterials(), fetchOverview(), fetchAnalytics(), fetchUsers(), fetchCurriculum(), fetchQuestions(), fetchModeration(), fetchSchoolAnalytics(), fetchBilling(), fetchPersonas(), fetchErrorLogs(), fetchPendingTeachers(),
    ]);
    setLoading(false);
  };

  const fetchSubjects = async () => {
    const { data } = await supabase.from('subjects').select('*').order('display_order');
    if (data) setSubjects(data as Subject[]);
  };

  const fetchMaterials = async () => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
    const { data: { session: authSession } } = await supabase.auth.getSession();
    const response = await fetch(`${supabaseUrl}/functions/v1/content-materials`, {
      headers: { ...(authSession ? { Authorization: `Bearer ${authSession.access_token}` } : {}) },
    });
    if (response.ok) { const { data } = await response.json(); setMaterials(data || []); }
  };

  const fetchOverview = async () => {
    const [usersRes, topicsRes, lessonsRes, questionsRes] = await Promise.all([
      supabase.from('profiles').select('grade, role, full_name, created_at, id'),
      supabase.from('topics').select('id, subject_id, subject:subjects(name, color)'),
      supabase.from('lessons').select('id', { count: 'exact', head: true }),
      supabase.from('practice_questions').select('id', { count: 'exact', head: true }),
    ]);

    setUserCount(usersRes.data?.length || 0);
    setTopicCount(topicsRes.data?.length || 0);
    setLessonCount(lessonsRes.count || 0);
    setQuestionCount(questionsRes.count || 0);

    const gradeMap: Record<number, number> = {};
    (usersRes.data || []).forEach((u: any) => { gradeMap[u.grade] = (gradeMap[u.grade] || 0) + 1; });
    setUsersByGrade(gradeMap);

    const subjMap: Record<string, { count: number; color: string }> = {};
    (topicsRes.data || []).forEach((t: any) => {
      const name = t.subject?.name || 'Unassigned';
      const color = t.subject?.color || '#888';
      if (!subjMap[name]) subjMap[name] = { count: 0, color };
      subjMap[name].count++;
    });
    setTopicsBySubject(Object.entries(subjMap).map(([subject, v]) => ({ subject, count: v.count, color: v.color })));

    const sorted = (usersRes.data || []).slice().sort((a: any, b: any) =>
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    ).slice(0, 5);
    setRecentSignups(sorted as UserProfile[]);

    // Activity feed
    const [sessionsRes, attemptsRes] = await Promise.all([
      supabase.from('lesson_sessions').select('id, user_id, lesson_id, status, completed_at, lesson:lessons(title)').eq('status', 'completed').order('completed_at', { ascending: false }).limit(10),
      supabase.from('practice_attempts').select('id, user_id, is_correct, created_at, question:practice_questions(question_text)').order('created_at', { ascending: false }).limit(10),
    ]);

    const userMap: Record<string, string> = {};
    (usersRes.data || []).forEach((u: any) => { userMap[u.id] = u.full_name; });

    const activities: ActivityItem[] = [];
    (sessionsRes.data || []).forEach((s: any) => {
      activities.push({
        id: s.id, type: 'lesson_completed', user_name: userMap[s.user_id] || 'Unknown',
        detail: s.lesson?.title || 'Lesson', timestamp: s.completed_at,
      });
    });
    (attemptsRes.data || []).forEach((a: any) => {
      activities.push({
        id: a.id, type: 'practice_attempt', user_name: userMap[a.user_id] || 'Unknown',
        detail: `${a.is_correct ? 'Correct' : 'Incorrect'}: ${a.question?.question_text?.slice(0, 50) || 'Question'}`,
        timestamp: a.created_at,
      });
    });
    activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    setActivityFeed(activities.slice(0, 15));
  };

  const fetchAnalytics = async () => {
    const [sessionsRes, attemptsRes, progressRes, providerRes] = await Promise.all([
      supabase.from('lesson_sessions').select('id, status'),
      supabase.from('practice_attempts').select('id, is_correct'),
      supabase.from('progress_records').select('mastery_percentage'),
      supabase.from('platform_settings').select('value').eq('key', 'primary_ai_provider').maybeSingle(),
    ]);
    setPrimaryAiProviderState(providerRes.data?.value === 'anthropic' ? 'anthropic' : 'openai');

    const sessions = sessionsRes.data || [];
    const attempts = attemptsRes.data || [];
    const progress = progressRes.data || [];

    setSessionCount(sessions.length);
    setCompletedSessionCount(sessions.filter((s: any) => s.status === 'completed').length);
    setAttemptCount(attempts.length);
    setCorrectAttemptCount(attempts.filter((a: any) => a.is_correct).length);

    const masteryValues = progress.map((p: any) => Number(p.mastery_percentage));
    setAvgMastery(masteryValues.length > 0 ? Math.round(masteryValues.reduce((a: number, b: number) => a + b, 0) / masteryValues.length) : 0);

    const ranges = [
      { range: '0-20%', min: 0, max: 20 },
      { range: '21-40%', min: 21, max: 40 },
      { range: '41-60%', min: 41, max: 60 },
      { range: '61-80%', min: 61, max: 80 },
      { range: '81-100%', min: 81, max: 100 },
    ];
    setMasteryDistribution(ranges.map(r => ({
      range: r.range,
      count: masteryValues.filter((v: number) => v >= r.min && v <= r.max).length,
    })));

    const { data: qData } = await supabase.from('practice_questions').select('id, topic_id, topic:topics(subject_id, subject:subjects(name, color))');
    const qSubjMap: Record<string, { count: number; color: string }> = {};
    (qData || []).forEach((q: any) => {
      const name = q.topic?.subject?.name || 'Unassigned';
      const color = q.topic?.subject?.color || '#888';
      if (!qSubjMap[name]) qSubjMap[name] = { count: 0, color };
      qSubjMap[name].count++;
    });
    setQuestionsBySubject(Object.entries(qSubjMap).map(([subject, v]) => ({ subject, count: v.count, color: v.color })));

    // AI Teaching Insights — continuous learning pipeline, "analyze
    // performance" step (SRS 12.17). Aggregated client-side since this is
    // read via the anon/authenticated client, not a service-role RPC.
    const { data: aiLogs } = await supabase
      .from('ai_interaction_logs')
      .select('topic_id, source, detected_confusion, topic:topics(name)')
      .order('created_at', { ascending: false })
      .limit(1000);
    const logs = aiLogs || [];
    setAiTotalMessages(logs.length);
    // Fallback rate = "no real AI provider was used to answer" (neither
    // OpenAI nor Anthropic configured, or both calls failed) — deliberately
    // excludes rate_limited and moderated, since being blocked on purpose
    // (rate limit) or intercepted before reaching the teaching LLM
    // (moderation) isn't the same signal as the AI being unavailable, and
    // mixing them would make the fallback rate look worse than it actually
    // is without telling you why. Counts 'anthropic' as a real answer, not
    // a fallback — ai-teacher-chat can be answered by either provider (see
    // supabase/functions/_shared/llm.ts), so only the literal string
    // 'fallback' (the rule-based canned response, used when neither
    // provider works) should count against this rate.
    const answeredLogs = logs.filter((l: any) => l.source !== 'rate_limited' && l.source !== 'moderated');
    setAiFallbackRate(answeredLogs.length > 0 ? Math.round((answeredLogs.filter((l: any) => l.source === 'fallback').length / answeredLogs.length) * 100) : 0);
    setAiConfusionRate(logs.length > 0 ? Math.round((logs.filter((l: any) => l.detected_confusion).length / logs.length) * 100) : 0);
    setAiRateLimitedCount(logs.filter((l: any) => l.source === 'rate_limited').length);

    const topicMap: Record<string, { count: number; confusionCount: number }> = {};
    logs.forEach((l: any) => {
      const name = l.topic?.name || 'General / no topic';
      if (!topicMap[name]) topicMap[name] = { count: 0, confusionCount: 0 };
      topicMap[name].count++;
      if (l.detected_confusion) topicMap[name].confusionCount++;
    });
    setAiTopTopics(
      Object.entries(topicMap)
        .map(([topic, v]) => ({ topic, count: v.count, confusionCount: v.confusionCount }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 6)
    );

    // AI Evaluation Suite history (SRS 12.16) — populated by
    // scripts/run-ai-evaluation.js, run outside the app (a dev machine or
    // CI) against real curriculum test cases. Nothing in the deployed app
    // writes to these tables; this is read-only history.
    const { data: evalRunsData } = await supabase
      .from('ai_eval_runs')
      .select('*')
      .order('run_at', { ascending: false })
      .limit(10);
    setAiEvalRuns(evalRunsData || []);
  };

  const USERS_PAGE_SIZE = 50;

  // Real pagination — the previous version fetched every single pupil
  // account with no limit at all, which is exactly the kind of thing
  // that works fine at a handful of test users and becomes a serious
  // problem well before real scale. Search and the Form filter are now
  // applied server-side (ilike/eq before .range()), not client-side on
  // whatever page happens to be loaded — filtering only the current
  // page's 50 rows would silently miss matches on every other page,
  // which would be worse than not having search at all.
  const fetchUsers = async () => {
    const from = usersPage * USERS_PAGE_SIZE;
    const to = from + USERS_PAGE_SIZE - 1;
    let query = supabase.from('profiles').select('*', { count: 'exact' }).order('created_at', { ascending: false });
    if (userSearch.trim()) query = query.ilike('full_name', `%${userSearch.trim()}%`);
    if (userGradeFilter !== null) query = query.eq('grade', userGradeFilter);
    const { data, count } = await query.range(from, to);
    if (data) setUsers(data as UserProfile[]);
    setUsersTotalCount(count ?? 0);
  };

  // Deliberately separate from the paginated users list above — if this
  // were derived from `users` (the current page's 50 rows), a pending
  // teacher waiting for approval could be genuinely invisible to the
  // admin whenever their row falls on a page that isn't currently
  // loaded. This is inherently a small, bounded "needs attention" queue
  // (there shouldn't be hundreds of pending teachers at once), so an
  // unpaginated query for exactly this is the right call, not a scale risk.
  const fetchPendingTeachers = async () => {
    const { data } = await supabase
      .from('profiles').select('*')
      .eq('role', 'teacher').eq('teacher_approved', false)
      .order('created_at', { ascending: false });
    setPendingTeachers(data || []);
  };

  const fetchCurriculum = async () => {
    const [topicsRes, lessonsRes] = await Promise.all([
      supabase.from('topics').select('*, subject:subjects(name, color)').order('grade, display_order'),
      supabase.from('lessons').select('*, topic:topics(name, subject:subjects(name, color))').order('display_order'),
    ]);
    setTopics(topicsRes.data as Topic[] || []);
    setLessons(lessonsRes.data as Lesson[] || []);
  };

  const fetchQuestions = async () => {
    const { data } = await supabase.from('practice_questions').select('*, topic:topics(name, subject:subjects(name, color))').order('difficulty');
    if (data) setQuestions(data as PracticeQuestion[]);
  };

  // Moderation — messages OpenAI's Moderation API flagged before they
  // reached the teaching LLM (see ai-teacher-chat's moderateMessage()).
  // Self-harm severity sorted first, unreviewed before reviewed, so the
  // thing most needing a human's attention is always at the top rather
  // than buried under routine flags in chronological order.
  const MODERATION_PAGE_SIZE = 50;

  // Split deliberately, not paginated as one list: unreviewed flags stay
  // fully unpaginated (self-harm-first sort applied here, not per-page —
  // a self-harm flag on "page 2" of a naive pagination scheme could go
  // unseen by an admin only looking at page 1, which is the one outcome
  // this can't risk). This is inherently a small, bounded needs-action
  // queue if actively managed, same reasoning as pending teachers below.
  // Reviewed flags (historical record, fine to page through) are paginated.
  const fetchModeration = async () => {
    setModerationLoading(true);
    const [unreviewedRes, reviewedRes, cleanupRes] = await Promise.all([
      supabase.from('moderation_flags').select('*, profile:profiles(full_name)')
        .eq('reviewed', false).order('created_at', { ascending: false }),
      supabase.from('moderation_flags').select('*, profile:profiles(full_name)', { count: 'exact' })
        .eq('reviewed', true).order('created_at', { ascending: false })
        .range(moderationPage * MODERATION_PAGE_SIZE, moderationPage * MODERATION_PAGE_SIZE + MODERATION_PAGE_SIZE - 1),
      supabase.from('moderation_flags_cleanup_log').select('*').order('run_at', { ascending: false }).limit(20),
    ]);
    const unreviewedSorted = (unreviewedRes.data || []).sort((a: any, b: any) =>
      a.severity === b.severity ? 0 : a.severity === 'self_harm' ? -1 : 1
    );
    setModerationFlags([...unreviewedSorted, ...(reviewedRes.data || [])]);
    setModerationReviewedTotalCount(reviewedRes.count ?? 0);
    setModerationCleanupLog(cleanupRes.data || []);
    setModerationLoading(false);
  };

  const handleMarkReviewed = async (id: string) => {
    const { error } = await supabase
      .from('moderation_flags')
      .update({ reviewed: true, reviewed_by: profile?.id, reviewed_at: new Date().toISOString() })
      .eq('id', id);
    if (error) { toast.error('Failed to update.'); return; }
    setModerationFlags((prev) => prev.map((f) => (f.id === id ? { ...f, reviewed: true } : f)));
  };

  // School/teacher analytics — aggregated mastery and common
  // misconceptions, filterable by school and Form. All three RPCs are
  // admin-gated server-side (get_school_topic_analytics,
  // get_common_misconceptions, get_distinct_schools all check the
  // caller's role themselves), so this isn't relying on RLS alone.
  const fetchSchoolAnalytics = async () => {
    setSchoolAnalyticsLoading(true);
    const [schoolsRes, topicRes, mistakesRes] = await Promise.all([
      supabase.rpc('get_distinct_schools'),
      supabase.rpc('get_school_topic_analytics', {
        p_school: schoolFilter || null,
        p_grade: schoolGradeFilter,
      }),
      supabase.rpc('get_common_misconceptions', {
        p_school: schoolFilter || null,
        p_grade: schoolGradeFilter,
        p_topic_id: null,
      }),
    ]);
    setSchoolList(schoolsRes.data || []);
    setSchoolTopicAnalytics(topicRes.data || []);
    setCommonMisconceptions(mistakesRes.data || []);
    setSchoolAnalyticsLoading(false);
  };

  // Billing — real payments (via DPO Group), the global free-mode
  // toggle, and per-pupil bonus grants. Revenue summary comes from
  // get_revenue_summary(), which only counts payments.status = 'completed'
  // — pending/failed attempts are visible in the payments list itself for
  // troubleshooting, but never counted as revenue.
  const PAYMENTS_PAGE_SIZE = 50;

  const fetchBilling = async () => {
    setBillingLoading(true);
    const [paymentsRes, revenueRes, settingsRes, subscribersRes] = await Promise.all([
      supabase.from('payments').select('*, profile:profiles(full_name)', { count: 'exact' })
        .order('created_at', { ascending: false })
        .range(paymentsPage * PAYMENTS_PAGE_SIZE, paymentsPage * PAYMENTS_PAGE_SIZE + PAYMENTS_PAGE_SIZE - 1),
      supabase.rpc('get_revenue_summary'),
      supabase.from('platform_settings').select('*').in('key', ['is_platform_free', 'subscription_price_zmw']),
      supabase.rpc('get_subscribers_by_subject'),
    ]);
    setPayments(paymentsRes.data || []);
    setPaymentsTotalCount(paymentsRes.count ?? 0);
    setRevenueSummary(revenueRes.data || []);
    const settings = settingsRes.data || [];
    setIsPlatformFree(settings.find((s: any) => s.key === 'is_platform_free')?.value === true);
    setSubscriptionPrice(Number(settings.find((s: any) => s.key === 'subscription_price_zmw')?.value ?? 50));
    setSubscribersBySubject(subscribersRes.data || []);
    setBillingLoading(false);
  };

  const handleToggleFreeMode = async (enabled: boolean) => {
    const { error } = await supabase.rpc('set_platform_free_mode', { p_enabled: enabled });
    if (error) { toast.error('Failed to update free mode.'); return; }
    setIsPlatformFree(enabled);
    toast.success(enabled ? 'Platform is now free for everyone.' : 'Free mode turned off — the daily quota applies again.');
  };

  const handleUpdatePrice = async (newPrice: number) => {
    const { error } = await supabase
      .from('platform_settings')
      .update({ value: newPrice, updated_at: new Date().toISOString(), updated_by: profile?.id })
      .eq('key', 'subscription_price_zmw');
    if (error) { toast.error('Failed to update price.'); return; }
    setSubscriptionPrice(newPrice);
    toast.success('Subscription price updated.');
  };

  const handleSetPrimaryProvider = async (provider: string) => {
    const { error } = await supabase
      .from('platform_settings')
      .update({ value: provider, updated_at: new Date().toISOString(), updated_by: profile?.id })
      .eq('key', 'primary_ai_provider');
    if (error) { toast.error('Failed to update AI provider preference.'); return; }
    setPrimaryAiProviderState(provider);
    toast.success(`${provider === 'anthropic' ? 'Anthropic (Claude)' : 'OpenAI'} will be tried first for new teaching responses.`);
  };

  // Upsert, not update — alert_email isn't pre-seeded by the migration
  // (an empty/placeholder address sending real alerts would be worse
  // than not alerting at all), so the row may not exist yet the first
  // time an admin sets one.
  const handleSaveAlertEmail = async (email: string) => {
    const { error } = await supabase
      .from('platform_settings')
      .upsert({ key: 'alert_email', value: email, updated_at: new Date().toISOString(), updated_by: profile?.id }, { onConflict: 'key' });
    if (error) { toast.error('Failed to save alert email.'); return; }
    setAlertEmail(email);
    toast.success(email ? 'Error alerts will be sent to this address.' : 'Error alerts disabled.');
  };

  const fetchPersonas = async () => {
    setPersonasLoading(true);
    const { data } = await supabase
      .from('teacher_personas')
      .select('*, subject:subjects(name, color)')
      .order('name');
    setPersonas(data || []);
    setPersonasLoading(false);
  };

  const fetchErrorLogs = async () => {
    setErrorLogsLoading(true);
    const [logsRes, settingRes] = await Promise.all([
      supabase.from('app_error_log').select('*').order('created_at', { ascending: false }).limit(200),
      supabase.from('platform_settings').select('value').eq('key', 'alert_email').maybeSingle(),
    ]);
    setErrorLogs(logsRes.data || []);
    setAlertEmail(typeof settingRes.data?.value === 'string' ? settingRes.data.value : '');
    setErrorLogsLoading(false);
  };

  const handleSavePersona = async (id: string, avatarId: string, voiceId: string) => {
    const { error } = await supabase
      .from('teacher_personas')
      .update({
        liveavatar_avatar_id: avatarId || null,
        liveavatar_voice_id: voiceId || null,
      })
      .eq('id', id);
    if (error) { toast.error('Failed to save. Did the 20260802080000 migration run?'); return; }
    toast.success('Saved.');
    fetchPersonas();
  };

  const handleGrantBonus = async (userId: string, days: number | null) => {
    const { error } = await supabase.rpc('grant_bonus_subscription', { p_user_id: userId, p_days: days });
    if (error) { toast.error('Failed to grant bonus access.'); return; }
    toast.success('Bonus access granted.');
  };

  const handleIssueWarning = async (userId: string, reason: string, flagId?: string) => {
    const { error } = await supabase.rpc('issue_warning', {
      p_user_id: userId, p_reason: reason, p_moderation_flag_id: flagId || null,
    });
    if (error) { toast.error('Failed to issue warning.'); return; }
    toast.success('Warning sent to pupil.');
  };

  // Deletion is genuinely irreversible — an Edge Function rather than a
  // plain RPC, since removing the real auth.users row needs the Auth
  // Admin API, which only a service-role server context can call. The
  // frontend's own confirmation (typing "DELETE") already happened
  // before this fires; this is the actual deletion, not another
  // confirmation step.
  const handleDeleteAccount = async (userId: string, reason: string) => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
    const { data: { session: authSession } } = await supabase.auth.getSession();
    if (!authSession) { toast.error('Please log in again.'); return; }
    const response = await fetch(`${supabaseUrl}/functions/v1/delete-user-account`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authSession.access_token}` },
      body: JSON.stringify({ userId, reason }),
    });
    const data = await response.json();
    if (!response.ok) { toast.error(data.error || 'Failed to delete account.'); return; }
    toast.success('Account deleted.');
    fetchUsers();
    fetchModeration();
  };

  // Materials handlers
  const handleAdd = async () => {
    if (!form.title || !form.source) { toast.error('Title and source are required.'); return; }
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
    const { data: { session: authSession } } = await supabase.auth.getSession();
    const response = await fetch(`${supabaseUrl}/functions/v1/content-materials`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(authSession ? { Authorization: `Bearer ${authSession.access_token}` } : {}) },
      body: JSON.stringify({
        title: form.title, source: form.source, material_type: form.material_type,
        subject_id: form.subject_id || null, grade: form.grade ? parseInt(form.grade) : null,
        source_reference: form.source_reference || null, content_summary: form.content_summary || null, status: form.status,
      }),
    });
    if (response.ok) {
      toast.success('Material added.');
      setForm({ title: '', source: '', material_type: 'supplementary', subject_id: '', grade: '', source_reference: '', content_summary: '', status: 'pending' });
      setShowAddForm(false); fetchMaterials();
    } else { toast.error('Failed to add.'); }
  };

  const handleUpdate = async (id: string, updates: Partial<ContentMaterial>) => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
    const { data: { session: authSession } } = await supabase.auth.getSession();
    const response = await fetch(`${supabaseUrl}/functions/v1/content-materials`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...(authSession ? { Authorization: `Bearer ${authSession.access_token}` } : {}) },
      body: JSON.stringify({ id, ...updates }),
    });
    if (response.ok) { toast.success('Updated.'); setEditingId(null); fetchMaterials(); }
    else { toast.error('Failed to update.'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this material?')) return;
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
    const { data: { session: authSession } } = await supabase.auth.getSession();
    const response = await fetch(`${supabaseUrl}/functions/v1/content-materials/${id}`, {
      method: 'DELETE',
      headers: { ...(authSession ? { Authorization: `Bearer ${authSession.access_token}` } : {}) },
    });
    if (response.ok) { toast.success('Deleted.'); fetchMaterials(); }
    else { toast.error('Failed to delete.'); }
  };

  const handleSync = async (source: 'moe' | 'ecz' | 'all') => {
    setSyncing(source); setSyncResult(null);
    try {
      const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
      const { data: { session: authSession } } = await supabase.auth.getSession();
      const response = await fetch(`${supabaseUrl}/functions/v1/moe-ecz-sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(authSession ? { Authorization: `Bearer ${authSession.access_token}` } : {}) },
        body: JSON.stringify({ source }),
      });
      if (response.ok) {
        const data = await response.json();
        setSyncResult({ source: data.source, message: data.message });
        toast.success(data.message); fetchMaterials();
      } else { const err = await response.json(); toast.error(err.error || 'Sync failed.'); }
    } catch { toast.error('Sync failed.'); }
    setSyncing(null);
  };

  // Generates embeddings for any content_materials / search_index /
  // past_paper_questions rows missing one (SRS 12.6 — real pgvector
  // search). The Edge Function processes a bounded batch per call, so
  // this loops until every table reports 0 remaining, updating progress
  // as it goes rather than blocking on one giant request.
  const handleGenerateEmbeddings = async () => {
    setEmbedding(true);
    setEmbeddingResult(null);
    try {
      const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
      const { data: { session: authSession } } = await supabase.auth.getSession();
      const headers = { 'Content-Type': 'application/json', ...(authSession ? { Authorization: `Bearer ${authSession.access_token}` } : {}) };

      let totalEmbedded = 0;
      let totalFailed = 0;
      let remaining = 1; // seed the loop
      let guard = 0; // hard stop in case something's stuck, rather than looping forever

      while (remaining > 0 && guard < 25) {
        guard++;
        const response = await fetch(`${supabaseUrl}/functions/v1/generate-embeddings`, {
          method: 'POST', headers, body: JSON.stringify({ table: 'all', limit: 20 }),
        });
        if (!response.ok) {
          const err = await response.json().catch(() => ({}));
          toast.error(err.error || 'Embedding generation failed.');
          break;
        }
        const data = await response.json();
        remaining = 0;
        for (const table of Object.keys(data.results || {})) {
          const r = data.results[table];
          totalEmbedded += r.embedded;
          totalFailed += r.failed;
          remaining = Math.max(remaining, r.remaining);
        }
        setEmbeddingResult({ embedded: totalEmbedded, failed: totalFailed, remaining });
      }
      toast.success(`Embedded ${totalEmbedded} rows${totalFailed ? `, ${totalFailed} failed` : ''}.`);
    } catch {
      toast.error('Embedding generation failed.');
    }
    setEmbedding(false);
  };

  // Lesson handlers
  const handleLessonSubmit = async () => {
    if (!lessonForm.topic_id || !lessonForm.title) { toast.error('Topic and title are required.'); return; }
    const content: LessonContent = { intro: lessonForm.intro, steps: [], examples: [], summary: lessonForm.summary };
    if (editingLesson) {
      const { error } = await supabase.from('lessons').update({
        topic_id: lessonForm.topic_id, title: lessonForm.title, difficulty: lessonForm.difficulty,
        display_order: lessonForm.display_order, content,
      }).eq('id', editingLesson.id);
      if (error) { toast.error('Failed to update lesson.'); return; }
      toast.success('Lesson updated.');
    } else {
      const { error } = await supabase.from('lessons').insert({
        topic_id: lessonForm.topic_id, title: lessonForm.title, difficulty: lessonForm.difficulty,
        display_order: lessonForm.display_order, content,
      });
      if (error) { toast.error('Failed to create lesson.'); return; }
      toast.success('Lesson created.');
    }
    setShowLessonForm(false); setEditingLesson(null);
    setLessonForm({ topic_id: '', title: '', difficulty: 'standard', display_order: 0, intro: '', summary: '' });
    fetchCurriculum();
  };

  const handleLessonEdit = (lesson: Lesson) => {
    setEditingLesson(lesson);
    setLessonForm({
      topic_id: lesson.topic_id, title: lesson.title, difficulty: lesson.difficulty,
      display_order: lesson.display_order,
      intro: lesson.content?.intro || '', summary: lesson.content?.summary || '',
    });
    setShowLessonForm(true);
  };

  const handleLessonDelete = async (id: string) => {
    if (!confirm('Delete this lesson?')) return;
    const { error } = await supabase.from('lessons').delete().eq('id', id);
    if (error) { toast.error('Failed to delete.'); return; }
    toast.success('Lesson deleted.'); fetchCurriculum();
  };

  // Question handlers
  const handleQuestionSubmit = async () => {
    if (!questionForm.topic_id || !questionForm.question_text || !questionForm.answer_key) {
      toast.error('Topic, question text, and answer are required.'); return;
    }
    const payload = {
      topic_id: questionForm.topic_id,
      question_text: questionForm.question_text,
      question_type: questionForm.question_type,
      options: questionForm.question_type === 'multiple_choice' ? questionForm.options.filter((o: string) => o.trim()) : null,
      answer_key: questionForm.answer_key,
      explanation: questionForm.explanation || null,
      difficulty: questionForm.difficulty,
    };
    if (editingQuestion) {
      const { error } = await supabase.from('practice_questions').update(payload).eq('id', editingQuestion.id);
      if (error) { toast.error('Failed to update question.'); return; }
      toast.success('Question updated.');
    } else {
      const { error } = await supabase.from('practice_questions').insert(payload);
      if (error) { toast.error('Failed to create question.'); return; }
      toast.success('Question created.');
    }
    setShowQuestionForm(false); setEditingQuestion(null);
    setQuestionForm({ topic_id: '', question_text: '', question_type: 'multiple_choice', options: ['', '', '', ''], answer_key: '', explanation: '', difficulty: 'standard' });
    fetchQuestions();
  };

  const handleQuestionEdit = (q: PracticeQuestion) => {
    setEditingQuestion(q);
    setQuestionForm({
      topic_id: q.topic_id, question_text: q.question_text, question_type: q.question_type,
      options: (q.options as string[]) || ['', '', '', ''], answer_key: q.answer_key,
      explanation: q.explanation || '', difficulty: q.difficulty,
    });
    setShowQuestionForm(true);
  };

  const handleQuestionDelete = async (id: string) => {
    if (!confirm('Delete this question?')) return;
    const { error } = await supabase.from('practice_questions').delete().eq('id', id);
    if (error) { toast.error('Failed to delete.'); return; }
    toast.success('Question deleted.'); fetchQuestions();
  };

  // User handlers
  const toggleUserRole = async (userId: string, currentRole: string) => {
    const newRole = currentRole === 'admin' ? 'pupil' : 'admin';
    const { error } = await supabase.from('profiles').update({ role: newRole }).eq('id', userId);
    if (error) { toast.error('Failed to update role.'); return; }
    toast.success(`Role set to ${newRole}.`); fetchUsers();
  };

  const handleApproveTeacher = async (userId: string) => {
    const { error } = await supabase.from('profiles').update({ teacher_approved: true }).eq('id', userId);
    if (error) { toast.error('Failed to approve teacher.'); return; }
    toast.success('Teacher approved — they can now log in and see their school\'s analytics.');
    fetchUsers();
    fetchPendingTeachers();
  };

  const openUserDetail = async (user: UserProfile) => {
    setSelectedUser(user);
    const [progressRes, sessionsRes] = await Promise.all([
      supabase.from('progress_records').select('*, topic:topics(name, subject:subjects(name, color))').eq('user_id', user.id),
      supabase.from('lesson_sessions').select('*, lesson:lessons(title)').eq('user_id', user.id).order('started_at', { ascending: false }).limit(10),
    ]);
    setUserProgress(progressRes.data || []);
    setUserSessions(sessionsRes.data || []);
  };

  // Search index rebuild
  const rebuildSearchIndex = async () => {
    if (!confirm('Rebuild the search index? This will reindex all topics and lessons.')) return;
    const { error } = await supabase.rpc('rebuild_search_index');
    if (error) { toast.error('Rebuild failed.'); return; }
    toast.success('Search index rebuilt successfully.');
  };

  if (!isAdmin || loading) {
    return <div className="flex h-72 items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-gold" /></div>;
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gold/20 border border-gold/40 flex items-center justify-center">
          <Shield className="h-5 w-5 text-gold" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-semibold text-chalk">Admin Dashboard</h1>
          <p className="text-muted-board text-sm">Manage platform content, users, curriculum, and analytics.</p>
        </div>
      </div>

      <div className="flex gap-1 border-b border-white/10 overflow-x-auto scrollbar-thin">
        {TABS.map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeTab === tab.id ? 'border-gold text-gold' : 'border-transparent text-muted-board hover:text-chalk'
            }`}>
            {tab.icon}{tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <OverviewTab
          userCount={userCount} topicCount={topicCount} lessonCount={lessonCount} questionCount={questionCount}
          materialCount={materials.length} approvedMaterials={materials.filter((m) => m.status === 'approved').length}
          usersByGrade={usersByGrade} topicsBySubject={topicsBySubject}
          activityFeed={activityFeed} recentSignups={recentSignups}
        />
      )}

      {activeTab === 'analytics' && (
        <AnalyticsTab
          sessionCount={sessionCount} completedSessionCount={completedSessionCount}
          attemptCount={attemptCount} correctAttemptCount={correctAttemptCount}
          avgMastery={avgMastery} masteryDistribution={masteryDistribution}
          questionsBySubject={questionsBySubject} userCount={userCount}
          aiTotalMessages={aiTotalMessages} aiFallbackRate={aiFallbackRate}
          aiConfusionRate={aiConfusionRate} aiTopTopics={aiTopTopics}
          aiRateLimitedCount={aiRateLimitedCount} aiEvalRuns={aiEvalRuns}
          primaryAiProvider={primaryAiProvider} onSetPrimaryProvider={handleSetPrimaryProvider}
        />
      )}

      {activeTab === 'materials' && (
        <MaterialsTab
          materials={materials} subjects={subjects} showAddForm={showAddForm} setShowAddForm={setShowAddForm}
          form={form} setForm={setForm} handleAdd={handleAdd} handleUpdate={handleUpdate} handleDelete={handleDelete}
          handleSync={handleSync} syncing={syncing} syncResult={syncResult} editingId={editingId} setEditingId={setEditingId}
          handleGenerateEmbeddings={handleGenerateEmbeddings} embedding={embedding} embeddingResult={embeddingResult}
        />
      )}

      {activeTab === 'lessons' && (
        <LessonsTab
          lessons={lessons} topics={topics} subjects={subjects}
          lessonSearch={lessonSearch} setLessonSearch={setLessonSearch}
          lessonTopicFilter={lessonTopicFilter} setLessonTopicFilter={setLessonTopicFilter}
          showLessonForm={showLessonForm} setShowLessonForm={setShowLessonForm}
          editingLesson={editingLesson} lessonForm={lessonForm} setLessonForm={setLessonForm}
          handleLessonSubmit={handleLessonSubmit} handleLessonEdit={handleLessonEdit} handleLessonDelete={handleLessonDelete}
        />
      )}

      {activeTab === 'questions' && (
        <QuestionsTab
          questions={questions} topics={topics} subjects={subjects}
          questionSearch={questionSearch} setQuestionSearch={setQuestionSearch}
          questionTopicFilter={questionTopicFilter} setQuestionTopicFilter={setQuestionTopicFilter}
          showQuestionForm={showQuestionForm} setShowQuestionForm={setShowQuestionForm}
          editingQuestion={editingQuestion} questionForm={questionForm} setQuestionForm={setQuestionForm}
          handleQuestionSubmit={handleQuestionSubmit} handleQuestionEdit={handleQuestionEdit} handleQuestionDelete={handleQuestionDelete}
        />
      )}

      {activeTab === 'users' && (
        <UsersTab
          users={users} userSearch={userSearch} setUserSearch={setUserSearch}
          userGradeFilter={userGradeFilter} setUserGradeFilter={setUserGradeFilter}
          toggleUserRole={toggleUserRole} currentUserId={profile?.id}
          selectedUser={selectedUser} setSelectedUser={setSelectedUser}
          openUserDetail={openUserDetail} userProgress={userProgress} userSessions={userSessions}
          onApproveTeacher={handleApproveTeacher} pendingTeachers={pendingTeachers}
          usersPage={usersPage} setUsersPage={setUsersPage} usersTotalCount={usersTotalCount} pageSize={USERS_PAGE_SIZE}
        />
      )}

      {activeTab === 'curriculum' && (
        <CurriculumTab
          subjects={subjects} topics={topics} lessons={lessons}
          curriculumSubjectFilter={curriculumSubjectFilter} setCurriculumSubjectFilter={setCurriculumSubjectFilter}
        />
      )}

      {activeTab === 'moderation' && (
        <ModerationTab
          flags={moderationFlags} loading={moderationLoading} onMarkReviewed={handleMarkReviewed}
          cleanupLog={moderationCleanupLog} onIssueWarning={handleIssueWarning} onDeleteAccount={handleDeleteAccount}
          moderationPage={moderationPage} setModerationPage={setModerationPage}
          reviewedTotalCount={moderationReviewedTotalCount} pageSize={MODERATION_PAGE_SIZE}
        />
      )}

      {activeTab === 'school-analytics' && (
        <SchoolAnalyticsTab
          schoolList={schoolList} topicAnalytics={schoolTopicAnalytics} misconceptions={commonMisconceptions}
          loading={schoolAnalyticsLoading} schoolFilter={schoolFilter} setSchoolFilter={setSchoolFilter}
          gradeFilter={schoolGradeFilter} setGradeFilter={setSchoolGradeFilter}
        />
      )}

      {activeTab === 'billing' && (
        <BillingTab
          payments={payments} revenueSummary={revenueSummary} subscribersBySubject={subscribersBySubject}
          isPlatformFree={isPlatformFree} subscriptionPrice={subscriptionPrice} loading={billingLoading}
          onToggleFreeMode={handleToggleFreeMode} onUpdatePrice={handleUpdatePrice} onGrantBonus={handleGrantBonus}
          paymentsPage={paymentsPage} setPaymentsPage={setPaymentsPage}
          paymentsTotalCount={paymentsTotalCount} pageSize={PAYMENTS_PAGE_SIZE}
        />
      )}

      {activeTab === 'personas' && (
        <PersonasTab personas={personas} loading={personasLoading} onSave={handleSavePersona} />
      )}

      {activeTab === 'system-health' && (
        <SystemHealthTab errors={errorLogs} loading={errorLogsLoading} alertEmail={alertEmail} onSaveAlertEmail={handleSaveAlertEmail} />
      )}

      {activeTab === 'settings' && (
        <SettingsTab profile={profile} rebuildSearchIndex={rebuildSearchIndex} />
      )}
    </div>
  );
}
