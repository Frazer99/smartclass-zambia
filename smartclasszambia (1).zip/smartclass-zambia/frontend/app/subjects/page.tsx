"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import RequireAuth from "@/components/RequireAuth";
import { api, ApiError } from "@/lib/api";

type Topic = { id: number; title: string; description?: string; order_index: number };
type PastPaperQ = { id: number; question_number: string; question_text: string; marks?: number };
type PastPaper = { id: number; year: number; term?: string; title: string; questions: PastPaperQ[] };

function SubjectsInner() {
  const params = useSearchParams();
  const router = useRouter();
  const subjectId = Number(params.get("subjectId"));
  const formLevel = Number(params.get("formLevel"));
  const [tab, setTab] = useState<"lesson" | "pastpaper">((params.get("tab") as any) || "lesson");

  const [topics, setTopics] = useState<Topic[]>([]);
  const [papers, setPapers] = useState<PastPaper[]>([]);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [selectedQuestions, setSelectedQuestions] = useState<Record<number, number[]>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!subjectId || !formLevel) return;
    api.get(`/api/catalog/topics?subject_id=${subjectId}&form_level=${formLevel}`).then(setTopics);
    api.get(`/api/catalog/past-papers?subject_id=${subjectId}&form_level=${formLevel}`).then(setPapers);
  }, [subjectId, formLevel]);

  async function startLesson(topicId: number) {
    setBusy(true);
    setError(null);
    try {
      const session = await api.post("/api/lessons/start", { subject_id: subjectId, topic_id: topicId });
      router.push(`/classroom?mode=lesson&sessionId=${session.id}&subjectId=${subjectId}`);
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  async function startPastPaper(paperId: number, questionIds?: number[]) {
    setBusy(true);
    setError(null);
    try {
      const session = await api.post("/api/past-papers/start", {
        past_paper_id: paperId,
        question_ids: questionIds && questionIds.length ? questionIds : undefined,
      });
      router.push(`/classroom?mode=pastpaper&sessionId=${session.id}&subjectId=${subjectId}`);
    } catch (err) {
      handleError(err);
    } finally {
      setBusy(false);
    }
  }

  function handleError(err: unknown) {
    if (err instanceof ApiError && err.status === 402) {
      router.push(`/classroom?mode=paywall&subjectId=${subjectId}`);
      return;
    }
    setError(err instanceof ApiError ? err.message : "Something went wrong");
  }

  function toggleQuestion(paperId: number, qId: number) {
    setSelectedQuestions((prev) => {
      const cur = prev[paperId] || [];
      const next = cur.includes(qId) ? cur.filter((x) => x !== qId) : [...cur, qId];
      return { ...prev, [paperId]: next };
    });
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="flex gap-2 mb-8 border-b border-brand-100">
        <button
          onClick={() => setTab("lesson")}
          className={`px-4 py-2 font-semibold border-b-2 ${tab === "lesson" ? "border-brand-600 text-brand-900" : "border-transparent text-brand-500"}`}
        >
          Lesson
        </button>
        <button
          onClick={() => setTab("pastpaper")}
          className={`px-4 py-2 font-semibold border-b-2 ${tab === "pastpaper" ? "border-brand-600 text-brand-900" : "border-transparent text-brand-500"}`}
        >
          Past Paper
        </button>
      </div>

      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

      {tab === "lesson" && (
        <div className="grid md:grid-cols-2 gap-4">
          {topics.length === 0 && <p className="text-brand-700">No topics yet -- an admin needs to upload the syllabus for this subject/Form.</p>}
          {topics.map((t) => (
            <div key={t.id} className="card">
              <h4 className="font-bold text-brand-900">{t.title}</h4>
              {t.description && <p className="text-brand-700 text-sm mt-1">{t.description}</p>}
              <button className="btn-primary mt-4 text-sm py-2" onClick={() => startLesson(t.id)} disabled={busy}>
                Start lesson with AI teacher
              </button>
            </div>
          ))}
        </div>
      )}

      {tab === "pastpaper" && (
        <div className="space-y-4">
          {papers.length === 0 && <p className="text-brand-700">No past papers uploaded yet for this subject/Form.</p>}
          {papers.map((p) => (
            <div key={p.id} className="card">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-brand-900">{p.title}</h4>
                  <p className="text-brand-700 text-sm">
                    {p.year} {p.term ? `- ${p.term}` : ""} &middot; {p.questions.length} question(s)
                  </p>
                </div>
                <div className="flex gap-2">
                  <button className="btn-secondary text-sm py-2" onClick={() => setExpanded(expanded === p.id ? null : p.id)}>
                    {expanded === p.id ? "Hide questions" : "Pick a question"}
                  </button>
                  <button className="btn-primary text-sm py-2" onClick={() => startPastPaper(p.id)} disabled={busy}>
                    Do full paper
                  </button>
                </div>
              </div>

              {expanded === p.id && (
                <div className="mt-4 border-t border-brand-100 pt-4 space-y-2">
                  {p.questions.map((q) => (
                    <label key={q.id} className="flex items-start gap-2 text-sm">
                      <input
                        type="checkbox"
                        className="mt-1"
                        checked={(selectedQuestions[p.id] || []).includes(q.id)}
                        onChange={() => toggleQuestion(p.id, q.id)}
                      />
                      <span>
                        <strong>Q{q.question_number}</strong> ({q.marks ?? "?"} marks) - {q.question_text}
                      </span>
                    </label>
                  ))}
                  <button
                    className="btn-primary mt-3 text-sm py-2"
                    disabled={busy || !(selectedQuestions[p.id] || []).length}
                    onClick={() => startPastPaper(p.id, selectedQuestions[p.id])}
                  >
                    Start selected question(s) with AI teacher
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function SubjectsPage() {
  return (
    <RequireAuth>
      <Suspense fallback={<div className="max-w-6xl mx-auto px-4 py-16">Loading...</div>}>
        <SubjectsInner />
      </Suspense>
    </RequireAuth>
  );
}
