# Pupil-facing subscription status & learning profile — update only

Same pattern as every previous update: just the files touched this
session, same relative paths, drop straight in and overwrite. No
migration, no new secret, no Edge Function — both features read data
that already existed.

## New files (2)
components/SubscriptionStatus.tsx
    Mounted on /account. Shows current subscription status (active,
    bonus grant, or none), expiry date, and payment history. Purely
    reads subscriptions/payments via RLS a pupil already had access to
    — no new access grant, just new UI.

components/LearningProfile.tsx
    Mounted on /progress. Shows the pupil's preferred explanation style
    (get_preferred_learning_style()) and which topics are currently
    getting an escalated, different explanation approach
    (topic_explanation_attempts). Uses its own STRATEGY_LABELS —
    pupil-friendly phrasing, deliberately NOT the same strings
    ai-teacher-chat uses internally to instruct the AI.

    Verified with a real screenshot: a preferred style and a
    currently-escalating topic both rendering correctly and genuinely
    distinct from each other.

## Modified files (2)
app/(app)/account/page.tsx
    Mounts SubscriptionStatus, right before the existing "Your Data"
    section.

app/(app)/progress/page.tsx
    Mounts LearningProfile, right after the existing stat notes row.

README.md
    New "Pupil-Facing Subscription Status & Learning Profile" section.

## After copying these in
Nothing to deploy beyond the normal Next.js build — no migration, no
secret, no Edge Function. Both components read tables/functions that
already exist from earlier updates (subscriptions_payments migration,
learning_style_adaptation migration).
