'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase-client';
import { CreditCard, Gift, Loader as Loader2 } from 'lucide-react';

interface SubscriptionRow {
  status: string;
  is_bonus_grant: boolean;
  expires_at: string | null;
  plan_type: string;
}

interface PaymentRow {
  id: string;
  amount: number;
  currency: string;
  payment_method: 'mobile_money' | 'card';
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  created_at: string;
}

/**
 * Real subscription visibility for the person actually paying — until
 * now, only the admin Billing tab could show whether a pupil's
 * subscription was active, when it expired, or their payment history.
 * A pupil (or the parent paying for them) had no way to check this
 * themselves without asking an admin. Purely additive: the RLS policies
 * already let a pupil read their own subscriptions/payments rows
 * (select_own_subscription, select_own_payments, migration
 * 20260727080000) — this is a new UI reading data that was already
 * theirs to see, not a new access grant.
 */
export function SubscriptionStatus() {
  const [subscription, setSubscription] = useState<SubscriptionRow | null>(null);
  const [payments, setPayments] = useState<PaymentRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { setLoading(false); return; }
      const [subRes, paymentsRes] = await Promise.all([
        supabase.from('subscriptions').select('status, is_bonus_grant, expires_at, plan_type')
          .eq('user_id', session.user.id).eq('status', 'active')
          .order('expires_at', { ascending: false, nullsFirst: false }).limit(1).maybeSingle(),
        supabase.from('payments').select('id, amount, currency, payment_method, status, created_at')
          .eq('user_id', session.user.id).order('created_at', { ascending: false }).limit(10),
      ]);
      setSubscription(subRes.data);
      setPayments(paymentsRes.data || []);
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return <div className="flex h-24 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>;
  }

  const isActive = subscription && (subscription.expires_at === null || new Date(subscription.expires_at) > new Date());

  return (
    <div className="space-y-4">
      <div className="card-board p-5">
        <div className="flex items-center gap-2 mb-3">
          {subscription?.is_bonus_grant ? <Gift className="h-5 w-5 text-gold" /> : <CreditCard className="h-5 w-5 text-gold" />}
          <h2 className="font-display text-lg font-semibold text-chalk">My Subscription</h2>
        </div>
        {isActive ? (
          <>
            <p className="text-sm text-chalk mb-1">
              {subscription!.is_bonus_grant ? 'Bonus access — active' : 'Subscription active'}
            </p>
            <p className="text-xs text-muted-board">
              {subscription!.expires_at
                ? `Renews or expires ${new Date(subscription!.expires_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}`
                : 'No expiry set — granted for ongoing access'}
            </p>
            {!subscription!.is_bonus_grant && (
              <Link href="/subscribe" className="inline-block mt-3 text-xs border border-white/15 text-muted-board hover:text-chalk rounded-lg px-3 py-1.5 transition-colors">
                Extend subscription
              </Link>
            )}
          </>
        ) : (
          <>
            <p className="text-sm text-muted-board mb-3">No active subscription — using the free daily message limit.</p>
            <Link href="/subscribe" className="btn-gold text-sm px-4 py-2 inline-block">Subscribe →</Link>
          </>
        )}
      </div>

      {payments.length > 0 && (
        <div className="card-board p-5">
          <h3 className="font-display text-sm font-semibold text-chalk mb-3">Payment History</h3>
          <div className="space-y-2">
            {payments.map((p) => (
              <div key={p.id} className="flex items-center justify-between text-sm">
                <span className="text-chalk capitalize">{p.payment_method.replace('_', ' ')}</span>
                <span className="text-xs text-muted-board">
                  {new Date(p.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                </span>
                <span className="font-mono-sc text-chalk">K{Number(p.amount).toFixed(2)}</span>
                <span className={`text-xs ${p.status === 'completed' ? 'text-teal' : p.status === 'pending' ? 'text-gold' : 'text-rust'}`}>
                  {p.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
