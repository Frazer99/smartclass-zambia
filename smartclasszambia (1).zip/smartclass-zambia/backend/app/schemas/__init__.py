from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, EmailStr, Field


# ---- Auth ----
class RegisterRequest(BaseModel):
    full_name: str
    email: EmailStr
    phone: Optional[str] = None
    password: str = Field(min_length=6)
    form_level: Optional[int] = Field(default=None, ge=2, le=6)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    full_name: str
    email: str
    phone: Optional[str] = None
    role: str
    form_level: Optional[int] = None

    class Config:
        from_attributes = True


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---- Catalog ----
class SubjectOut(BaseModel):
    id: int
    name: str
    description: Optional[str] = None

    class Config:
        from_attributes = True


class TopicOut(BaseModel):
    id: int
    subject_id: int
    form_level: int
    title: str
    description: Optional[str] = None
    order_index: int

    class Config:
        from_attributes = True


class MaterialOut(BaseModel):
    id: int
    subject_id: int
    form_level: int
    topic_id: Optional[int] = None
    title: str
    material_type: str
    filename: str
    uploaded_at: datetime

    class Config:
        from_attributes = True


class SyllabusUploadOut(BaseModel):
    id: int
    subject_id: int
    form_level: int
    filename: str
    parsed: bool
    topics_created: int = 0


# ---- Past papers ----
class PastPaperQuestionOut(BaseModel):
    id: int
    question_number: str
    question_text: str
    marks: Optional[int] = None
    topic_id: Optional[int] = None

    class Config:
        from_attributes = True


class PastPaperOut(BaseModel):
    id: int
    subject_id: int
    form_level: int
    year: int
    term: Optional[str] = None
    title: str
    questions: list[PastPaperQuestionOut] = []

    class Config:
        from_attributes = True


class PastPaperQuestionCreate(BaseModel):
    question_number: str
    question_text: str
    marks: Optional[int] = None
    topic_id: Optional[int] = None
    answer_guide: Optional[str] = None


class PastPaperCreate(BaseModel):
    subject_id: int
    form_level: int
    year: int
    term: Optional[str] = None
    title: str
    questions: list[PastPaperQuestionCreate] = []


# ---- Lesson / AI teacher ----
class WhiteboardLine(BaseModel):
    type: str = "text"  # text | formula | diagram | heading
    content: str


class LessonMessageOut(BaseModel):
    id: int
    role: str
    content: str
    whiteboard: Optional[list[dict]] = None
    created_at: datetime

    class Config:
        from_attributes = True


class LessonSessionOut(BaseModel):
    id: int
    mode: str
    subject_id: int
    topic_id: Optional[int] = None
    past_paper_id: Optional[int] = None
    started_at: datetime
    ended_at: Optional[datetime] = None
    duration_seconds: int
    messages: list[LessonMessageOut] = []

    class Config:
        from_attributes = True


class StartLessonRequest(BaseModel):
    subject_id: int
    topic_id: int


class StartPastPaperRequest(BaseModel):
    past_paper_id: int
    question_ids: Optional[list[int]] = None  # None = whole paper, else specific question(s)


class SendMessageRequest(BaseModel):
    session_id: int
    content: str
    elapsed_seconds: int = Field(default=5, ge=0, le=600, description="Seconds since last message, for trial-time accounting")


class TrialStatusOut(BaseModel):
    subject_id: int
    seconds_used: int
    seconds_allowed: int
    seconds_remaining: int
    has_active_subscription: bool


# ---- Progress ----
class ProgressOut(BaseModel):
    subject_id: int
    topic_id: int
    topic_title: str
    mastery_score: float
    lessons_completed: int
    questions_attempted: int
    questions_correct: int

    class Config:
        from_attributes = True


# ---- Subscriptions / Payments ----
class SubscriptionOut(BaseModel):
    id: int
    subject_id: int
    status: str
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    amount_zmw: float

    class Config:
        from_attributes = True


class InitiatePaymentRequest(BaseModel):
    subject_id: int
    method: str = Field(description="mtn_momo | airtel_money | visa")
    msisdn: Optional[str] = Field(default=None, description="Required for mtn_momo / airtel_money")


class PaymentOut(BaseModel):
    id: int
    subject_id: int
    amount_zmw: float
    method: str
    status: str
    provider_reference: Optional[str] = None

    class Config:
        from_attributes = True


class PaymentWebhookPayload(BaseModel):
    provider_reference: str
    status: str  # success | failed
    extra: Optional[dict[str, Any]] = None
