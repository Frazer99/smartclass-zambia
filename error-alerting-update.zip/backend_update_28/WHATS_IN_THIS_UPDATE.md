# Real error alerting (email) — update only

Same pattern as every previous update: just the files touched this
session, same relative paths, drop straight in and overwrite.

## New files (2)
supabase/migrations/20260806080000_error_alerting.sql
    - app_error_log.alert_sent column (throttling tracker)
    - trigger_error_alert(): fires on new app_error_log rows, checks
      for a same-source alert in the last 15 minutes, sends via pg_net
      to the new edge function if not throttled
    - Reuses the SAME app.settings.supabase_url /
      app.settings.supabase_service_role_key prerequisite already
      required for the weekly digest — if you haven't done that setup,
      this won't work either, same as the digest wouldn't

supabase/functions/send-error-alert/index.ts
    Sends the actual email via the existing Resend integration (same
    _shared/email.ts already used by send-welcome-email and
    send-weekly-digest). Only ever called by the database trigger, not
    directly by the frontend.
    Deploy: supabase functions deploy send-error-alert

## Modified files (2)
app/admin/(protected)/tabs/system-health-tab.tsx
    New "Error Alerts" section: set (or clear, to disable) the email
    address alerts go to.

app/admin/(protected)/page.tsx
    Wires it in: alertEmail state, fetchErrorLogs extended to also read
    the setting, handleSaveAlertEmail (uses upsert, not update — the
    setting isn't pre-seeded).

README.md
    New "Real Error Alerting" section, plus a "Legal Documents" section
    describing the two draft Word documents (delivered separately, not
    part of this code package — see the main chat response for those).

## After copying these in
1. Run the new migration in the Supabase SQL editor
2. supabase functions deploy send-error-alert
3. No new secrets — reuses RESEND_API_KEY / EMAIL_FROM, already
   required for welcome emails and the weekly digest
4. If you haven't already done the app.settings Postgres setup for the
   weekly digest, do that first — this feature has the same prerequisite
5. Set a real alert email from /admin -> System Health once deployed
