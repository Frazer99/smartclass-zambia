"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/lib/auth";
import { ApiError } from "@/lib/api";

export default function RegisterPage() {
  const { register } = useAuth();
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [formLevel, setFormLevel] = useState(4);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await register({ full_name: fullName, email, password, phone, form_level: formLevel });
      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Registration failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="card">
        <h1 className="text-2xl font-bold text-brand-900 mb-1">Create your account</h1>
        <p className="text-brand-700 mb-6">10 minutes free per subject -- no card needed to start.</p>
        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-brand-800 mb-1">Full name</label>
            <input className="input" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
          </div>
          <div>
            <label className="block text-sm font-medium text-brand-800 mb-1">Email</label>
            <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div>
            <label className="block text-sm font-medium text-brand-800 mb-1">Phone (for mobile money later)</label>
            <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+2609XXXXXXXX" />
          </div>
          <div>
            <label className="block text-sm font-medium text-brand-800 mb-1">Form / Grade</label>
            <select className="input" value={formLevel} onChange={(e) => setFormLevel(Number(e.target.value))}>
              <option value={2}>Form 2</option>
              <option value={3}>Form 3</option>
              <option value={4}>Form 4</option>
              <option value={5}>Form 5</option>
              <option value={6}>Form 6</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-brand-800 mb-1">Password</label>
            <input
              className="input"
              type="password"
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && <p className="text-red-600 text-sm">{error}</p>}
          <button className="btn-primary w-full" disabled={busy}>
            {busy ? "Creating account..." : "Create account"}
          </button>
        </form>
        <p className="text-sm text-brand-700 mt-4">
          Already have an account?{" "}
          <Link href="/login" className="text-brand-600 font-semibold">
            Log in
          </Link>
        </p>
      </div>
    </div>
  );
}
